function startclient()
palmtxd = engineLoadTXD("gta_tree_palm.txd")
engineImportTXD(palmtxd, 622 )
local palmdff = engineLoadDFF('veg_palm03.dff', 0) 
engineReplaceModel(palmdff, 622)  
txd = engineLoadTXD("gta_tree_palm.txd")
engineImportTXD(txd, 621 )
dff = engineLoadDFF( "veg_palm02.dff",621)
engineReplaceModel ( dff, 621 )
	
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), startclient)

